#!/bin/sh
python /var/www/jinlian/manage.py runserver 0.0.0.0:80 > /var/log/django.log 2>&1 &
