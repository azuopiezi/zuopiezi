# coding:utf-8
from django.db import models
from django.contrib import admin
from django.forms import CheckboxSelectMultiple
import datetime
from django.utils import timezone



OK = 1
MAX_DEV_PER_CABINET = 42
# Create your models here.

'''
机房归属部门信息
'''
class idc_belong(models.Model):
	belong_name = models.CharField(u'部门-负责人',max_length=64)
	remark = models.TextField(u'备注',max_length = 256, blank = True, null = True)

	def __unicode__(self):
                return self.belong_name
        class Meta:
            verbose_name = verbose_name_plural = u'部门-负责人'
'''
IDC 机房联系人信息
'''
class idc_contact(models.Model):
	contact_name = models.CharField(u'联系人', max_length = 64)
	phone = models.CharField(u'电话', max_length = 64)
	remark = models.TextField(u'备注', max_length = 256, blank = True, null = True)

	def __unicode__(self):
            return self.contact_name
        class Meta:
            verbose_name = verbose_name_plural = u'IDC联系人列表'
            
"""
IDC 机房信息
"""

class idc_info(models.Model):
	idc_name = models.CharField(u'IDC机房名称', max_length = 32)
	belong = models.ForeignKey(idc_belong, verbose_name = u'归属于部门-负责人')
	location = models.CharField(u'放置位置', max_length = 256, blank = True, null = True)
	contacts = models.ManyToManyField(idc_contact, max_length = 64,verbose_name = u'联系人')
	remark = models.TextField(u'备注', max_length = 256, blank = True, null = True)

	def __unicode__(self):
            return self.idc_name
        class Meta:
            verbose_name = verbose_name_plural = u'IDC机房名称'

"""
IDC 机柜信息
"""
class cabinet_info(models.Model):
	cabinet_name = models.CharField(u'机柜编号', max_length = 32)
	belong_idc = models.ForeignKey(idc_info, verbose_name = u'归属机房')
	location = models.CharField(u'机柜位置', max_length = 256, blank = True, null = True)
	remark = models.TextField(u'备注', max_length = 256, blank = True, null = True)

	def __unicode__(self):
            return self.cabinet_name
        class Meta:
            verbose_name = verbose_name_plural = u'机柜编号'

"""
资料信息
"""
class data_info(models.Model):
	data_name = models.CharField(u'标题', max_length = 32)
	content = models.TextField(u'内容', max_length = 256, blank = True, null = True)
	remark = models.TextField(u'备注', max_length = 256, blank = True, null = True)

	def __unicode__(self):
            return self.data_name
        class Meta:
            verbose_name = verbose_name_plural = u'资料信息'

          
"""
IDC 设备类型
"""
class device_type(models.Model):
	device_name = models.CharField(u'设备类型', max_length = 32)
	remark = models.TextField(u'备注', max_length = 256, blank = True, null = True)

	def __unicode__(self):
            return self.device_name
        class Meta:
            verbose_name = verbose_name_plural = u'设备类型'
            

"""
IDC 服务类型
"""
class service_type(models.Model):
	service_name = models.CharField(u'服务类型', max_length = 32)
	remark = models.TextField(u'备注', max_length = 256, blank = True, null = True)

	def __unicode__(self):
            return self.service_name
        class Meta:
            verbose_name = verbose_name_plural = u'服务类型'

"""
IDC 项目类型
"""
class project_type(models.Model):
	project_name = models.CharField(u'项目类型', max_length = 32)
	remark = models.TextField(u'备注', max_length = 256, blank = True, null = True)

	def __unicode__(self):
            return self.project_name
        class Meta:
            verbose_name = verbose_name_plural = u'项目类型'            

'''
IDC 主机信息
'''
class Host(models.Model):
        SPEC_LIST = (
                ('1U','1U'),
                ('2U','2U'),
                ('3U','3U'),
                ('4U','4U'),
                ('5U','5U'),
                ('6U','6U'),

                )
        LOC_ID =[]
        for i in range(1,MAX_DEV_PER_CABINET +1):
                LOC_ID.append((i,i))

        hostname = models.CharField(u'主机',max_length=50)
        nat_ip = models.GenericIPAddressField(u'内网IP')
        net_ip = models.GenericIPAddressField(u'外网IP',null = True)
        vip_ip = models.GenericIPAddressField(u'虚IP',null = True)
        operation = models.CharField(u'操作系统',max_length=50)
        memory = models.CharField(u'内存',max_length=50)
        disk = models.CharField(u'磁盘',max_length=50,null = True)
        belong_cabinet = models.ForeignKey(cabinet_info,  verbose_name = u'机柜编号')
        belong_device = models.ForeignKey(device_type,  verbose_name = u'设备类型')
        vendor_id = models.CharField(u'供应商',max_length=50)
        spec = models.CharField(u'U位数', max_length = 32, choices = SPEC_LIST)
        loc = models.IntegerField(u'机架位', choices = LOC_ID, help_text='机架上的摆放顺序，从下至上')
        belong_project = models.ForeignKey(project_type,  verbose_name = u'项目类型')
        unique_id_NO = models.CharField(u'唯一识别号',max_length=50)
        cpu_core = models.CharField(u'CPU',max_length=50)
        Manufacturer = models.CharField(u'设备品牌',max_length=50, null = True)
        sn = models.CharField(u'序列号',max_length=50)
        domain_name = models.CharField(u'域名地址',max_length=50, null = True)
        belong_service = models.ForeignKey(service_type,  verbose_name = u'服务类型')
        port1 = models.CharField(u'应用端口1', max_length = 64, blank = True, null = True)
	port2 = models.CharField(u'应用端口2', max_length = 64, blank = True, null = True)
        mac = models.CharField(u'MAC 地址1', max_length = 64, blank = True, null = True)
        purchase_date = models.DateTimeField(u'购买日期',null = True)
        end_date = models.DateTimeField(u'到期日期',null = True)
        user = models.CharField(u'主机负责人', max_length = 32, blank = True, null = True)
        remark = models.TextField(u'备注', max_length = 256, blank = True, null = True)
        def __unicode__(self):
                return self.hostname
        class Meta:
                verbose_name = verbose_name_plural = u'IDC主机'
      

'''
阿里云主机信息
'''
class Aliyun(models.Model):
	SPEC_LIST = ((u'SLB固定带宽',u'SLB固定带宽'),(u'SLB实时带宽',u'SLB实时带宽'),)
        HOST_LIST = ((u'公有云',u'公有云'),(u'金融云',u'金融云'), )
        MEM_LIST = ((u'512M',u'512M'),(u'1G',u'1G'),(u'2G',u'2G'),(u'4G',u'4G'),(u'8G',u'8G'),(u'16G',u'16G'),(u'32G',u'32G'),(u'64G',u'64G'),)
        CPU_LIST = ((u'1核',u'1核'),(u'2核',u'2核'),(u'4核',u'4核'),(u'8核',u'8核'),(u'16核',u'16核'),(u'32核',u'32核'),(u'64核',u'64核'),)
        hostname = models.CharField(u'主机',max_length=50)
        nat_ip = models.GenericIPAddressField(u'内网IP')
        net_ip = models.GenericIPAddressField(u'外网IP',blank = True, null = True)
        SLB_ip = models.GenericIPAddressField(u'SLB IP',blank = True, null = True)
        SLB_type =  models.CharField(u'SLB 类型', max_length = 32, blank = True,choices = SPEC_LIST)
        operation = models.CharField(u'操作系统',blank = True,max_length=50)
        memory = models.CharField(u'内存', max_length = 32,blank = True, choices = MEM_LIST)
        sys_disk = models.CharField(u'系统磁盘',max_length=50,blank = True,null = True,default='20G')
        ex_disk = models.CharField(u'扩展磁盘',max_length=50,blank = True,null = True)
        aliyun_type =  models.CharField(u'阿里云类型', max_length = 32,blank = True, choices = HOST_LIST)
        network_bandwidth = models.CharField(u'带宽',max_length=50,blank = True,null = True)
        belong_project = models.ForeignKey(project_type,  verbose_name = u'项目类型',help_text='例如：PC 端，移动端，微信')
        cpu_core = models.CharField(u'CPU', max_length = 50,blank = True, choices = CPU_LIST)
        Manufacturer = models.CharField(u'设备品牌',max_length=50,blank = True, null = True)
        sn = models.CharField(u'序列号',max_length=50,blank = True)
        domain_name = models.CharField(u'域名地址',max_length=50,blank = True, null = True)
        belong_service = models.ForeignKey(service_type, verbose_name = u'服务类型',help_text='例如：Tomcat,php,mysql,nginx等')
        port = models.CharField(u'应用端口', max_length = 64, blank = True, null = True)
        mac = models.CharField(u'MAC 地址', max_length = 64, blank = True, null = True)
        purchase_date = models.DateTimeField(u'购买日期',blank = True,null = True)
        end_date = models.DateTimeField(u'到期日期',blank = True,null = True)
        user = models.CharField(u'主机负责人', max_length = 32, blank = True, null = True)
        remark = models.TextField(u'备注', max_length = 256, blank = True, null = True)


        def __unicode__(self):
                return self.hostname
        class Meta:
                verbose_name = verbose_name_plural = u'阿里云主机'
