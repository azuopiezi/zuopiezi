#coding:utf-8
from django.shortcuts import render

# Create your views here.


from django.http import HttpResponse
from hostinfo.models import Host,Aliyun,idc_belong,idc_contact,device_type,cabinet_info,idc_info,data_info

"""
IDC机房归属部门信息
"""


def index(req):
    print req
    if req.method == 'POST':
        belong_name = req.POST.get('belong_name')
        remark = req.POST.get('remark')
        try:
            idc_belong = idc_belong.objects.get(belong_name=belong_name)
        except:
            idc_belong = idc_belong()
  
        idc_belong.belong_name = belong_name
        idc_belong.remark = remark

        idc_belong.save()
  
        return HttpResponse('ok')
    else:
        return HttpResponse('no data')
"""
IDC 机房联系人信息
"""
def index(req):
    print req
    if req.method == 'POST':
        contact_name = req.POST.get('contact_name')
        phone = req.POST.get('phone')
        remark = req.POST.get('remark')
        try:
            idc_contact = idc_contact.objects.get(contact_name=contact_name)
        except:
            idc_contact = idc_contact()
  
        idc_contact.contact_name = contact_name
        idc_contact.phone = phone
        idc_contact.remark = remark
        idc_contact.save()
  
        return HttpResponse('ok')
    else:
        return HttpResponse('no data')

'''
IDC 机房信息
'''

def index(req):
    print req
    if req.method == 'POST':
        idc_name = req.POST.get('idc_name')
        belong = req.POST.get('belong')
        location = req.POST.get('location')
        contacts = req.POST.get('contacts')                         
        remark = req.POST.get('remark')
        try:
            idc_info = idc_info.objects.get(idc_name=idc_name)
        except:
            idc_info = idc_info()
  
        idc_info.idc_name = idc_name
        idc_info.belong = belong
        idc_info.location = location
        idc_info.contacts = contacts
        idc_info.remark = remark
        idc_info.save()
  
        return HttpResponse('ok')
    else:
        return HttpResponse('no data')

    

"""
IDC 机柜信息
"""
def index(req):
    print req
    if req.method == 'POST':
        cabinet_name = req.POST.get('cabinet_name')
        belong_idc = req.POST.get('belong_idc')
        location = req.POST.get('location')
        remark = req.POST.get('remark')
        try:
            cabinet_info = cabinet_info.objects.get(cabinet_name=cabinet_name)
        except:
            cabinet_info = cabinet_info()
  
        cabinet_info.cabinet_name = cabinet_name
        cabinet_info.belong_idc = belong_idc
        cabinet_info.location = location
        
        cabinet_info.remark = remark
        cabinet_info.save()
  
        return HttpResponse('ok')
    else:
        return HttpResponse('no data')

"""
资料信息
"""
def index(req):
    print req
    if req.method == 'POST':
        data_name = req.POST.get('data_name')
        content = req.POST.get('content')
        remark = req.POST.get('remark')
        try:
            data_info = data_info.objects.get(data_name=data_name)
        except:
            data_info = data_info()
  
        data_info.data_name = data_name
        data_info.content = content
        data_info.remark = remark
        cabinet_info.save()
  
        return HttpResponse('ok')
    else:
        return HttpResponse('no data')
    
    

"""
IDC 设备类型
"""
def index(req):
    print req
    if req.method == 'POST':
        device_name = req.POST.get('device_name')
        remark = req.POST.get('remark')
        try:
            device_type = device_type.objects.get(device_name=device_name)
        except:
            device_type = device_type()
  
        device_type.contact_name = contact_name
        
        device_type.remark = remark
        device_type.save()
  
        return HttpResponse('ok')
    else:
        return HttpResponse('no data')


    

"""
IDC 主机信息
""" 
# Create your views here.
def index(req):
    print req
    if req.method == 'POST':
        hostname = req.POST.get('hostname')
        ip = req.POST.get('ip')
        osversion = req.POST.get('osversion')
        memory = req.POST.get('memory')
        disk = req.POST.get('disk')
        vendor_id = req.POST.get('vendor_id')
        model_name = req.POST.get('model_name')
        cpu_core = req.POST.get('cpu_core')
        product = req.POST.get('product')
        Manufacturer = req.POST.get('Manufacturer')
        sn = req.POST.get('sn')
        try:
            host = Host.objects.get(hostname=hostname)
        except:
            host = Host()
  
        host.hostname = hostname
        host.ip = ip
        host.osversion = osversion
        host.memory = memory
        host.disk = disk
        host.vendor_id = vendor_id
        host.model_name = model_name
        host.cpu_core = cpu_core
        host.product = product
        host.Manufacturer = Manufacturer
        host.sn = sn
        host.save()
  
        return HttpResponse('ok')
    else:
        return HttpResponse('no data')
"""
阿里云主机信息
"""
def index(req):
    print req
    if req.method == 'POST':
        hostname = req.POST.get('hostname')
        ip = req.POST.get('ip')
        osversion = req.POST.get('osversion')
        memory = req.POST.get('memory')
        disk = req.POST.get('disk')
        vendor_id = req.POST.get('vendor_id')
        model_name = req.POST.get('model_name')
        cpu_core = req.POST.get('cpu_core')
        product = req.POST.get('product')
        Manufacturer = req.POST.get('Manufacturer')
        sn = req.POST.get('sn')
        try:
            aliyun = Aliyun.objects.get(hostname=hostname)
        except:
            aliyun = Aliyun()
  
        aliyun.hostname = hostname
        aliyun.ip = ip
        aliyun.osversion = osversion
        aliyun.memory = memory
        aliyun.disk = disk
        aliyun.vendor_id = vendor_id
        aliyun.model_name = model_name
        aliyun.cpu_core = cpu_core
        aliyun.product = product
        aliyun.Manufacturer = Manufacturer
        aliyun.sn = sn
        aliyun.save()
  
        return HttpResponse('ok')
    else:
        return HttpResponse('no data')

