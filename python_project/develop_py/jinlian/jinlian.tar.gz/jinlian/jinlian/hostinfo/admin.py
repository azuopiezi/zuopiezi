# coding:utf-8
from django.contrib import admin
from django.forms import CheckboxSelectMultiple



# Register your models here.

from hostinfo.models import Host,Aliyun,idc_belong,idc_contact,idc_info,cabinet_info,device_type,service_type,project_type,data_info




"""
IDC 机房主机信息
"""
class HostAdmin(admin.ModelAdmin):
    list_display = ['hostname']
    search_fields = ['hostname']
    list_per_page = 50
    ordering = ['id',]
    list_filter = ['hostname']


"""
阿里云主机信息
"""

class AliyunAdmin(admin.ModelAdmin):
    list_display = ['hostname','nat_ip','net_ip','SLB_ip','SLB_type','operation','memory','sys_disk','ex_disk','aliyun_type','network_bandwidth','belong_project','cpu_core','domain_name','belong_service','port','purchase_date','end_date','user','remark' ]
    search_fields = ['hostname','nat_ip','net_ip','SLB_ip','SLB_type','operation','memory','sys_disk','ex_disk','aliyun_type','network_bandwidth','cpu_core','Manufacturer','domain_name','port','mac','purchase_date','end_date','user','remark' ]
    list_per_page = 50
    ordering = ['id',]

"""
IDC 机房归属部门信息
"""    
class Idc_belongAdmin(admin.ModelAdmin):
    list_display = ['belong_name','remark']
    search_fields = ['belong_name','remark']
    list_per_page = 50
    ordering = ['id',]
    list_filter = ['belong_name']
"""
IDC 机房联系人信息
"""    
class Idc_contactAdmin(admin.ModelAdmin):
	list_display = ('contact_name', 'phone', 'remark')
	search_fields = ['contact_name', 'phone', 'remark']
	list_per_page = 50
	ordering = ('id',)

"""
IDC 机房信息
"""
class Idc_infoAdmin(admin.ModelAdmin):
    list_display = ('idc_name', 'belong', 'location','remark')
    search_fields = ['idc_name', 'location','remark']
    list_per_page = 50
    ordering = ('id',)
"""
IDC 机柜信息
"""    
class Cabinet_infoAdmin(admin.ModelAdmin):
    list_display = ('cabinet_name', 'belong_idc', 'location', 'remark')
    search_fields = ['cabinet_name','location', 'remark']
    list_per_page = 50
    ordering = ['belong_idc', 'cabinet_name', ]
"""
IDC 设备类型
"""    
class Device_typeAdmin(admin.ModelAdmin):
    list_display = ('device_name', 'remark')
    search_fields = ['device_name', 'remark']
    list_per_page = 50
    ordering = ['id', ]
"""
IDC 服务类型
"""    
class Service_typeAdmin(admin.ModelAdmin):
    list_display = ('service_name', 'remark')
    search_fields = ['service_name', 'remark']
    list_per_page = 50
    ordering = ['id', ]

"""
IDC 项目类型
"""    
class Project_typeAdmin(admin.ModelAdmin):
    list_display = ('project_name', 'remark')
    search_fields = ['project_name', 'remark']
    list_per_page = 50
    ordering = ['id', ]
"""
资料信息
"""    
class Data_infoAdmin(admin.ModelAdmin):
    list_display = ('data_name','content', 'remark')
    search_fields = ['data_name','content', 'remark']
    list_per_page = 50
    ordering = ['id', ]



 

admin.site.register(Host,HostAdmin)
admin.site.register(Aliyun,AliyunAdmin)
admin.site.register(idc_belong,Idc_belongAdmin)
admin.site.register(idc_contact,Idc_contactAdmin)
admin.site.register(idc_info,Idc_infoAdmin)
admin.site.register(cabinet_info,Cabinet_infoAdmin)
admin.site.register(device_type,Device_typeAdmin)
admin.site.register(service_type,Service_typeAdmin)
admin.site.register(project_type,Project_typeAdmin)
admin.site.register(data_info,Data_infoAdmin)



